import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-propuestas',
  templateUrl: './propuestas.component.html',
  styleUrls: ['./propuestas.component.css']
})
export class PropuestasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
